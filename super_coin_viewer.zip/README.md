# 🚀 Super Coin Viewer

A lightweight crypto viewer using **Binance** and **LBank** APIs with charts, notifications, and CSV export.

## Features
- Live BTC/USDT price (auto-updates every 10s)
- Uses Binance API (falls back to LBank if Binance fails)
- Interactive line chart (Chart.js)
- Desktop notifications + sound alerts
- Request logs with CSV export

## Hosting on GitHub Pages
1. Fork or create a new repository on GitHub.
2. Upload `index.html` (and this README if you like).
3. Go to **Settings > Pages > Deploy from branch > `main` branch, `/root`**.
4. Your site will be live at: `https://your-username.github.io/repository-name/`
